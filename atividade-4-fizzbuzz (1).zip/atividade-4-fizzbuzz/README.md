# Atividade 4 - Exercício sobre Git

Algoritmo FizzBuzz em Java.

## Como executar

1. Tenha o Java (JDK) instalado.
2. Abra o terminal nesta pasta.
3. Compile:

   javac FizzBuzz.java

4. Execute:

   java FizzBuzz

O programa recebe um número N e imprime os resultados de 1 até N:
- FizzBuzz para múltiplos de 3 e 5;
- Fizz para múltiplos de 3;
- Buzz para múltiplos de 5;
- o próprio número nos demais casos.
